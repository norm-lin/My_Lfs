"""Sample module with invalid __version__ string"""

__version__ = "not starting with a number"