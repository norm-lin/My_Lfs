
"""
A sample unimportable module with double assignment
"""

raise ImportError()

VERSION = __version__ = "0.1"
