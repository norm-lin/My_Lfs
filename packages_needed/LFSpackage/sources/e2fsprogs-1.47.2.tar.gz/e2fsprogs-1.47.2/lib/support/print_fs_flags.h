/*
 * print_flags.h -- header file for printing the fs flags
 */

void print_fs_flags(FILE * f, unsigned long flags);
